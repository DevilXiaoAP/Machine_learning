Neural Network Learning with Backpropagation
============================================

<h2>How to use this code:</h2>
1. install Octave or Matlab

2. fork this repo and clone it locally!

3. navigate into the folder with the above files

4. type ```ex4``` to the command line to view a digit recogition neural network
with about 95% success rate trained using backpropagation.